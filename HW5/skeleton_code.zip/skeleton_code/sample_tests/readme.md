We have provided four sample test cases to help you debug the program:

- `java SentimentAnalysis 0 train.txt test.txt` -> mode0.txt

- `java SentimentAnalysis 1 train.txt test.txt` -> mode1.txt

- `java SentimentAnalysis 2 train.txt test.txt` -> mode2.txt

- `java SentimentAnalysis 3 train.txt 5` -> mode3.txt