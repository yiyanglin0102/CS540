import javax.print.DocFlavor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Fill in the implementation details of the class DecisionTree using this file. Any methods or
 * secondary classes that you want are fine but we will only interact with those methods in the
 * DecisionTree framework.
 */
public class DecisionTreeImpl {
	public DecTreeNode root;
	public List<List<Integer>> trainData;
	public int maxPerLeaf;
	public int maxDepth;
	public int numAttr;

	// Build a decision tree given a training set
	DecisionTreeImpl(List<List<Integer>> trainDataSet, int mPerLeaf, int mDepth) {
		this.trainData = trainDataSet;
		this.maxPerLeaf = mPerLeaf;
		this.maxDepth = mDepth;
		if (this.trainData.size() > 0) this.numAttr = trainDataSet.get(0).size() - 1;
		this.root = buildTree();
	}
	
	private DecTreeNode buildTree() {
		// TODO: add code here	
		return buildTree(this.trainData, 0);
	}

	private DecTreeNode buildTree(List<List<Integer>> data, int depth){
		HashMap<Integer, Integer> count = count(data);

		int zero = count.get(0);
		int one = count.get(1);

		DecTreeNode node = checkStop(one, zero, depth, data);
		if(node != null){
			return node;
		}

		ArrayList<Integer> splitAttr = getSplitAttr(data);

		int attribute = splitAttr.get(0);
		int threshold = splitAttr.get(1);

		List<List<List<Integer>>> dataS = split(data, attribute, threshold);

		node = new DecTreeNode(0, attribute, threshold);
		node.left = buildTree(dataS.get(0), depth+1);
		node.right = buildTree(dataS.get(1), depth+1);
		return node;
	}

	private ArrayList<Integer> getSplitAttr(List<List<Integer>> data) {
		double entropy = calEntropy(data);
		int attribute = 0;
		int threshold = 0;
		double bestInfoGain = 0;

		for (int i = 0; i < this.numAttr; i++) {
			for (int j = 0; j < 10; j++) {
				int v = j+1;

				double ig = entropy - splitDataEntropy(data, i, v);
				if(ig > bestInfoGain){
					bestInfoGain = ig;
					attribute = i;
					threshold = v;
				}
			}
		}

		ArrayList<Integer> result =  new ArrayList<>();
		result.add(attribute);
		result.add(threshold);
		return result;
	}

	private double splitDataEntropy(List<List<Integer>> data, int attribute, int threshold) {
		List<List<List<Integer>>> result = split(data, attribute, threshold);
		List<List<Integer>> a = result.get(0);
		List<List<Integer>> b = result.get(1);
		double entropy = 0;

		if(a.size() != 0){
			entropy += ((double)a.size() / data.size()) * calEntropy(a);
		}

		if(b.size() != 0){
			entropy += ((double)b.size() / data.size()) * calEntropy(b);
		}

		return entropy;
	}

	private double calEntropy(List<List<Integer>> data) {
		double entropy = 0;
		HashMap<Integer, Integer> count = count(data);

		int zero = count.get(0);
		int one = count.get(1);

		if(zero != 0){
			double p = (double) zero / (zero + one);
			entropy -= p*Math.log(p)/Math.log(2);
		}

		if(one != 0){
			double p = (double) one / (zero + one);
			entropy -= p*Math.log(p)/Math.log(2);
		}

		return entropy;
	}


	private List<List<List<Integer>>> split(List<List<Integer>> data, int attribute, int threshold) {
		List<List<List<Integer>>> result = new ArrayList<>();
		List<List<Integer>> less = new ArrayList<>();
		List<List<Integer>> great = new ArrayList<>();
		result.add(less);
		result.add(great);
		for (List<Integer> datum : data) {
			if(datum.get(attribute) <= threshold){
				less.add(datum);
			}else{
				great.add(datum);
			}
		}
		return result;
	}

	private DecTreeNode checkStop(int one, int zero, int depth, List<List<Integer>> data){
		if(zero == 0){
			return new DecTreeNode(1, 0, 0);
		}

		if(one == 0){
			return new DecTreeNode(0, 0, 0);
		}

		if(data.size() <= this.maxPerLeaf || depth >= this.maxDepth){
			if(zero > one){
				return new DecTreeNode(0, 0, 0);
			}else{
				return new DecTreeNode(1, 0, 0);
			}
		}
		return null;
	}

	private HashMap<Integer, Integer> count(List<List<Integer>> data) {
		HashMap<Integer, Integer> result = new HashMap<>();
		result.put(0, 0);
		result.put(1, 0);
		for (List<Integer> datum : data) {
			Integer v = datum.get(datum.size()-1);
			if(!result.containsKey(v)){
				result.put(v, 0);
			}
			result.put(v, result.get(v)+1);
		}
		return result;
	}

	public int classify(List<Integer> instance) {
		// Note that the last element of the array is the label.
		return classify(instance, root);
	}

	private int classify(List<Integer> instance, DecTreeNode node){
		if(node.isLeaf()){
			return node.classLabel;
		}

		int value = instance.get(node.attribute);
		DecTreeNode next = value <= node.threshold ? node.left : node.right;
		return classify(instance, next);
	}
	
	// Print the decision tree in the specified format
	public void printTree() {
		printTreeNode("", this.root);
	}

	public void printTreeNode(String prefixStr, DecTreeNode node) {
		String printStr = prefixStr + "X_" + node.attribute;
		System.out.print(printStr + " <= " + String.format("%d", node.threshold));
		if(node.left.isLeaf()) {
			System.out.println(" : " + String.valueOf(node.left.classLabel));
		}
		else {
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.left);
		}
		System.out.print(printStr + " > " + String.format("%d", node.threshold));
		if(node.right.isLeaf()) {
			System.out.println(" : " + String.valueOf(node.right.classLabel));
		}
		else {
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.right);
		}
	}
	
	public double printTest(List<List<Integer>> testDataSet) {
		int numEqual = 0;
		int numTotal = 0;
		for (int i = 0; i < testDataSet.size(); i ++)
		{
			int prediction = classify(testDataSet.get(i));
			int groundTruth = testDataSet.get(i).get(testDataSet.get(i).size() - 1);
			System.out.println(prediction);
			if (groundTruth == prediction) {
				numEqual++;
			}
			numTotal++;
		}
		double accuracy = numEqual*100.0 / (double)numTotal;
		System.out.println(String.format("%.2f", accuracy) + "%");
		return accuracy;
	}
}
