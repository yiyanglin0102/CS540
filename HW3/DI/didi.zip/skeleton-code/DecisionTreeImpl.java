import java.util.ArrayList;
import java.util.List;

/**
 * Fill in the implementation details of the class DecisionTree using this file.
 * Any methods or secondary classes that you want are fine but we will only
 * interact with those methods in the DecisionTree framework.
 */
public class DecisionTreeImpl {
    public DecTreeNode root;
    public List<List<Integer>> trainData;
    public int maxPerLeaf;
    public int maxDepth;
    public int numAttr;
    private boolean first;
    public List<PairAtrr> attrList;

    DecisionTreeImpl(List<List<Integer>> trainDataSet, int mPerLeaf, int mDepth) {
        this.trainData = trainDataSet;
        this.maxPerLeaf = mPerLeaf;
        this.maxDepth = mDepth;
        if (this.trainData.size() > 0)
		{
			this.numAttr = trainDataSet.get(0).size() - 1;
		}
        attrList = new ArrayList<PairAtrr>();
        first = true;
        this.root = buildTree(0, trainData, maxPerLeaf, maxDepth);
    }

	private void reConstruct() {
		attrList.clear();
		for (int i = 0; i < numAttr; i++) // 0 ~ 8
		{
			attrList.add(new PairAtrr(i, 0, 0));
		}
	}

    private DecTreeNode buildTree(int depth, List<List<Integer>> trainData, int maxPerLeaf, int maxDepth) {
        reConstruct();
        if (depth == maxDepth || trainData.size() <= maxPerLeaf)
        {
            return getDecTreeNode(trainData);
        }

        PairAtrr att = selectBestAttr(trainData);//????

        if (att.infoGain > 0.0) {
            if (first) {
                first = false;
                root = new DecTreeNode(0, att.attribute, att.threshold);
                ArrayList<List<Integer>> left = new ArrayList();
                ArrayList<List<Integer>> right = new ArrayList();
                int label0 = 0;
                int label1 = 0;
                for (int i = 0; i < trainData.size(); i++) {

                    if (helperClassify(root, trainData.get(i)) == 0) {
                        left.add(trainData.get(i));
                        label0++;
                    } else if (helperClassify(root, trainData.get(i)) == 1) {
                        label1++;
                        right.add(trainData.get(i));
                    }

                }
                root.left = buildTree(1, left, maxPerLeaf, maxDepth);
                root.right = buildTree(1, right, maxPerLeaf, maxDepth);
                return root;
            } else {
                int attr = att.attribute;
                int thres = att.threshold;
                int label = 0;
                int label0 = 0;
                ArrayList<List<Integer>> left = new ArrayList();
                ArrayList<List<Integer>> right = new ArrayList();
                DecTreeNode node = new DecTreeNode(label, attr, thres);
                for (int i = 0; i < trainData.size(); i++) {
                    if (helperClassify(node, trainData.get(i)) == 0) {
                        left.add(trainData.get(i));
                        label0++;
                    } else if (helperClassify(node, trainData.get(i)) == 1) {

                        node.left = buildTree(depth + 1, left, maxPerLeaf, maxDepth);
                        node.right = buildTree(depth + 1, right, maxPerLeaf, maxDepth);
                    } else {
                        return getDecTreeNode(trainData);
                    }
                }
            }
        }
        return null;
    }

	public PairAtrr selectBestAttr(List<List<Integer>> trainData) {
		for (int i = 0; i < attrList.size(); i++) {
			int threshold = selecThres(attrList.get(i), trainData);
			attrList.get(i).threshold = threshold;
			attrList.get(i).infoGain = infoGain(attrList.get(i), threshold, trainData);
		}
		PairAtrr attribute = attrList.get(0);
		double ftGain = attrList.get(0).infoGain;
		for (int i = 1; i < attrList.size(); i++) {
			if (attrList.get(i).infoGain > ftGain) {
				attribute = attrList.get(i);
				ftGain = attrList.get(i).infoGain;
			}
		}
		return attribute;
	}

	private int selecThres(PairAtrr instance, List<List<Integer>> trainData) {
		int threshold = 1;
		double infoGain = infoGain(instance, threshold, trainData);
		for (int i = 2; i <= 9; i++) {
			if (infoGain < infoGain(instance, i, trainData)) {
				threshold = i;
				infoGain = infoGain(instance, i, trainData);
			}
		}
		return threshold;
	}

    private double entropy(List<List<Integer>> trainData) {
        if (trainData.size() == 0) {
            return 0.0;
        }
        double numOne = 0;
        double numZero = 0;
        for (int i = 0; i < trainData.size(); i++) {
            if (trainData.get(i).get(numAttr) == 0) {
                numOne += 1.0;
            } else {
                numZero += 1.0;
            }
        }
        double p0 = numOne / (numOne + numZero);
        double p1 = numZero / (numOne + numZero);
        double res = -1.0 * p0 * Math.log(p0) + (-1.0) * p1 * Math.log(p1);
        res = Math.abs(res);
        return res;
    }

    private DecTreeNode getDecTreeNode(List<List<Integer>> trainData) {
        int left1 = 0;
        int right1 = 0;
        int classLebel = -1;
        for (int w = 0; w < trainData.size(); w++) {
            if (trainData.get(w).get(numAttr) == 0) {
                left1++;
            } else if (trainData.get(w).get(numAttr) == 1) {
                right1++;
            }
            if (left1 > right1) {
                classLebel = 0;
            } else
                classLebel = 1;
        }
        DecTreeNode leaf = new DecTreeNode(classLebel, 0, 0);
        return leaf;
    }

    public int classify(List<Integer> instance, DecTreeNode node) {
        if (node.isLeaf()) {
            return node.classLabel;
        }
        if (helperClassify(node, instance) == 0) {
            return classify(instance, node.left);
        } else
            return classify(instance, node.right);
    }

    private int helperClassify(DecTreeNode node, List<Integer> instance) {
        int attribute = node.attribute;
        int threshold = node.threshold;
        if (instance.get(attribute) <= threshold)
            return 0;
        return 1;
    }

    private double infoGain(PairAtrr instance, int threshold, List<List<Integer>> trainData) {
        double entropy = entropy(trainData);
        double preL = 0;
        double preR = 0;
        double ce = 0.0;
        ArrayList<List<Integer>> leftList = new ArrayList<List<Integer>>();
        ArrayList<List<Integer>> rightList = new ArrayList<List<Integer>>();
        for (int i = 0; i < trainData.size(); i++) {
            if (trainData.get(i).get(instance.attribute) <= threshold) {
                preL += 1.0;
                leftList.add(trainData.get(i));
            } else {
                rightList.add(trainData.get(i));
                preR += 1.0;
            }
        }
        ce = preL / (preL + preR) * entropy(leftList) + preR / (preL + preR) * entropy(rightList);
        return entropy - ce;
    }

    // Print the decision tree in the specified format
    public void printTree() {
        printTreeNode("", this.root);
    }

    public void printTreeNode(String prefixStr, DecTreeNode node) {
        String printStr = prefixStr + "X_" + node.attribute;
        System.out.print(printStr + " <= " + String.format("%d", node.threshold));
        if (node.left.isLeaf()) {
            System.out.println(" : " + String.valueOf(node.left.classLabel));
        } else {
            System.out.println();
            printTreeNode(prefixStr + "|\t", node.left);
        }
        System.out.print(printStr + " > " + String.format("%d", node.threshold));
        if (node.right.isLeaf()) {
            System.out.println(" : " + String.valueOf(node.right.classLabel));
        } else {
            System.out.println();
            printTreeNode(prefixStr + "|\t", node.right);
        }
    }

    public double printTest(List<List<Integer>> testDataSet) {
        int numEqual = 0;
        int numTotal = 0;
        for (int i = 0; i < testDataSet.size(); i++) {
            int prediction = classify(testDataSet.get(i), root);
            int groundTruth = testDataSet.get(i).get(testDataSet.get(i).size() - 1);
            System.out.println(prediction);
            if (groundTruth == prediction) {
                numEqual++;
            }
            numTotal++;
        }
        double accuracy = numEqual * 100.0 / (double) numTotal;
        System.out.println(String.format("%.2f", accuracy) + "%");
        return accuracy;
    }
}
