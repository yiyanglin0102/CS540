import java.util.List;

public class PairAtrr
{
    public int attribute;
    public int threshold;
    double infoGain;

    PairAtrr(int attribute, int threshold, double infoGain)
    {
        this.attribute = attribute;
        this.threshold = threshold;
        this.infoGain = infoGain;
    }
}
